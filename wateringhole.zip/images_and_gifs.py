hug_gifs = [
  'https://i.imgur.com/TALeR5e.gif',
  'https://imgur.com/A5lJzmU.gif',
]

stab_gifs = [
  'https://imgur.com/kKCPlPz.gif'
]